
use gh4book;

alter table users modify pass char(64) charset gbk;
                                             