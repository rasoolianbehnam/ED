<?php      
echo  hash("md5", "gh4book", true);
echo "\n"; 
?>
