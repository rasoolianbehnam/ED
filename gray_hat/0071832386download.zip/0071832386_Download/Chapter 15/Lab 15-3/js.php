<html><body>
<script>
var a = '<?php echo $_GET['data'] ?>';
var b = 'other_value';
document.write('<textarea>' + a + '</textarea>');
</script>
</body></html>
